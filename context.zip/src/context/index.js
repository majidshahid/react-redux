import { createContext } from "react";

var Theme =createContext();
export default Theme;