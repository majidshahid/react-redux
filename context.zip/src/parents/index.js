
import Child from "./child"

function Parents (){
    return(
        <div>
            <h1>Parents</h1>
            <Child/>
        </div>
    )
}
export default Parents;